from io import BytesIO

from fastapi.testclient import TestClient

from app.main import app


client = TestClient(app)


def test_analyze_multiple_keeps_both_uploaded_files() -> None:
    csv_a = b"case_id,timestamp,activity,actor,duration_hours,status\nA1,2024-01-01T00:00:00Z,Created,Portal,0,open\nA1,2024-01-01T02:00:00Z,Resolved,Support,2,closed\n"
    csv_b = b"case_id,timestamp,activity,actor,duration_hours,status\nB1,2024-02-01T00:00:00Z,Created,Portal,0,open\nB1,2024-02-01T03:00:00Z,Investigate,Ops,3,in_progress\nB1,2024-02-01T05:00:00Z,Resolved,Ops,2,closed\n"

    response = client.post(
        "/api/analyze-multiple",
        files=[
            ("files", ("workflow_a.csv", BytesIO(csv_a), "text/csv")),
            ("files", ("workflow_b.csv", BytesIO(csv_b), "text/csv")),
        ],
    )

    assert response.status_code == 200
    payload = response.json()
    names = [item["dataset_name"] for item in payload["analyses"]]
    assert names == ["workflow_a.csv", "workflow_b.csv"]
    assert len(payload["analyses"]) == 2
    assert payload["failures"] == []
