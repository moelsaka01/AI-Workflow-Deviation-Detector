from pathlib import Path

import pandas as pd

from app.analyzer import WorkflowAnalyzer
from app.schemas import AnalysisConfig


def test_sample_analysis_has_expected_shape() -> None:
    data_path = Path(__file__).resolve().parent.parent / "data" / "sample_workflow.csv"
    df = pd.read_csv(data_path)
    analyzer = WorkflowAnalyzer(AnalysisConfig())
    result = analyzer.analyze(df)

    assert result.kpis.total_cases == 10
    assert result.kpis.total_events == len(df)
    assert len(result.dominant_path) >= 4
    assert result.kpis.deviation_rate > 0
    assert len(result.stage_bottlenecks) > 0
    assert len(result.handoff_risks) > 0
    assert len(result.recommendations) > 0
