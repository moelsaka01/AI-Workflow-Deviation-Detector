from io import BytesIO
from zipfile import ZipFile

import pandas as pd
import pytest
from fastapi import UploadFile

from app.ingestion import DatasetParser


parser = DatasetParser()


def test_read_excel_bytes() -> None:
    buf = BytesIO()
    pd.DataFrame(
        {
            "case_id": ["1"],
            "timestamp": ["2024-01-01T00:00:00Z"],
            "activity": ["Created"],
        }
    ).to_excel(buf, index=False)
    batch = parser.parse_bytes(buf.getvalue(), "workflow.xlsx")
    df = batch.datasets[0].data
    assert list(df.columns) == ["case_id", "timestamp", "activity"]


def test_read_zip_with_csv() -> None:
    raw = b"case_id,timestamp,activity\n1,2024-01-01T00:00:00Z,Created\n"
    buf = BytesIO()
    with ZipFile(buf, "w") as archive:
        archive.writestr("nested/workflow.csv", raw)
    upload = UploadFile(filename="bundle.zip", file=BytesIO(buf.getvalue()))
    batch = parser.parse_uploads([upload])
    assert batch.datasets[0].source_path == "bundle.zip::nested/workflow.csv"
    assert "activity" in batch.datasets[0].data.columns


def test_read_nested_zip_recursively() -> None:
    raw = b"case_id,timestamp,activity\n1,2024-01-01T00:00:00Z,Created\n"
    inner = BytesIO()
    with ZipFile(inner, "w") as archive:
        archive.writestr("deep/workflow.csv", raw)
    outer = BytesIO()
    with ZipFile(outer, "w") as archive:
        archive.writestr("nested/archive.zip", inner.getvalue())
    upload = UploadFile(filename="outer.zip", file=BytesIO(outer.getvalue()))
    batch = parser.parse_uploads([upload])
    assert batch.datasets[0].source_path == "outer.zip::nested/archive.zip::deep/workflow.csv"


@pytest.mark.skipif(__import__("importlib").util.find_spec("pm4py") is None, reason="pm4py not installed in test env")
def test_read_zip_with_xes_gz() -> None:
    import gzip

    sample_xes = b"""<?xml version='1.0' encoding='UTF-8' ?>
<log xes.version='1.0' xes.features='nested-attributes' openxes.version='1.0RC7' xmlns='http://www.xes-standard.org/'>
  <trace>
    <string key='concept:name' value='CASE-1'/>
    <event>
      <string key='concept:name' value='Created'/>
      <date key='time:timestamp' value='2024-01-01T00:00:00.000+00:00'/>
      <string key='org:resource' value='Portal'/>
    </event>
    <event>
      <string key='concept:name' value='Resolved'/>
      <date key='time:timestamp' value='2024-01-01T01:00:00.000+00:00'/>
      <string key='org:resource' value='Support'/>
    </event>
  </trace>
</log>"""
    buf = BytesIO()
    with ZipFile(buf, "w") as archive:
        archive.writestr("nested/BPI_Challenge_2012.xes.gz", gzip.compress(sample_xes))
    upload = UploadFile(filename="bundle.zip", file=BytesIO(buf.getvalue()))
    batch = parser.parse_uploads([upload])
    df = batch.datasets[0].data
    assert set(["case_id", "timestamp", "activity", "actor", "duration_hours", "status"]).issubset(df.columns)
    assert df["case_id"].iloc[0] == "CASE-1"
