const palette = ['#7a6cff', '#35d6cb', '#ffbd59', '#ff6c97', '#73ef8a', '#4f87ff'];

const els = {
  fileInput: document.getElementById('fileInput'),
  folderInput: document.getElementById('folderInput'),
  loadSampleBtn: document.getElementById('loadSampleBtn'),
  loadSampleBtnEmpty: document.getElementById('loadSampleBtnEmpty'),
  statusPill: document.getElementById('statusPill'),
  datasetLabel: document.getElementById('datasetLabel'),
  emptyState: document.getElementById('emptyState'),
  results: document.getElementById('results'),
  caseIdCol: document.getElementById('caseIdCol'),
  timestampCol: document.getElementById('timestampCol'),
  activityCol: document.getElementById('activityCol'),
  actorCol: document.getElementById('actorCol'),
  durationCol: document.getElementById('durationCol'),
  statusCol: document.getElementById('statusCol'),
  supportThreshold: document.getElementById('supportThreshold'),
  slaHours: document.getElementById('slaHours'),
  topN: document.getElementById('topN'),
  kpiGrid: document.getElementById('kpiGrid'),
  processMapSvg: document.getElementById('processMapSvg'),
  insightSlides: document.getElementById('insightSlides'),
  recommendationsList: document.getElementById('recommendationsList'),
  deviationDonut: document.getElementById('deviationDonut'),
  variantCards: document.getElementById('variantCards'),
  deviationCases: document.getElementById('deviationCases'),
  anomalySummary: document.getElementById('anomalySummary'),
  variantsTable: document.getElementById('variantsTable'),
  handoffNetwork: document.getElementById('handoffNetwork'),
  stageBars: document.getElementById('stageBars'),
  stageBottlenecks: document.getElementById('stageBottlenecks'),
  timelineCards: document.getElementById('timelineCards'),
  flowEdges: document.getElementById('flowEdges'),
  previewTable: document.getElementById('previewTable'),
  compareCards: document.getElementById('compareCards'),
  compareTable: document.getElementById('compareTable'),
  datasetSwitcher: document.getElementById('datasetSwitcher'),
  tabButtons: Array.from(document.querySelectorAll('.tab-btn')),
  tabPanels: Array.from(document.querySelectorAll('.tab-panel')),
  storyCards: Array.from(document.querySelectorAll('[data-story-card]')),
  storyDots: Array.from(document.querySelectorAll('[data-story-dot]')),
};

let storyTimer = null;
let insightTimer = null;
let insightIndex = 0;
let currentAnalyses = [];
let activeDatasetIndex = 0;

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function formatPct(value) {
  return `${(Number(value || 0) * 100).toFixed(1)}%`;
}

function setStatus(text, mode = 'idle') {
  els.statusPill.textContent = text;
  els.statusPill.className = `status-pill ${mode}`;
}

function setDatasetLabel(text) {
  els.datasetLabel.textContent = text;
}

function tableFromRows(rows, columns) {
  if (!rows || !rows.length) return '<div class="muted">No rows available.</div>';
  const head = columns.map((c) => `<th>${escapeHtml(c.label)}</th>`).join('');
  const body = rows.map((row) => `<tr>${columns.map((c) => `<td>${c.render ? c.render(row[c.key], row) : escapeHtml(row[c.key] ?? '—')}</td>`).join('')}</tr>`).join('');
  return `<div class="table-wrap"><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
}

function setCurrentAnalyses(analyses, activeIndex = 0) {
  currentAnalyses = Array.isArray(analyses) ? analyses : [];
  activeDatasetIndex = Math.min(Math.max(activeIndex, 0), Math.max(currentAnalyses.length - 1, 0));
}

function renderDatasetSwitcher() {
  if (!currentAnalyses.length) {
    els.datasetSwitcher.classList.add('hidden');
    els.datasetSwitcher.innerHTML = '';
    return;
  }
  if (currentAnalyses.length === 1) {
    els.datasetSwitcher.classList.add('hidden');
    els.datasetSwitcher.innerHTML = '';
    return;
  }

  els.datasetSwitcher.classList.remove('hidden');
  els.datasetSwitcher.innerHTML = `
    <div class="dataset-switcher-head">
      <div>
        <div class="eyebrow">Primary dataset</div>
        <strong>Choose which workflow drives the Overview, Deviations, Operations, and Data tabs.</strong>
      </div>
      <span class="chip">${currentAnalyses.length} datasets loaded</span>
    </div>
    <div class="dataset-chip-row">
      ${currentAnalyses.map((item, idx) => `
        <button class="dataset-chip ${idx === activeDatasetIndex ? 'active' : ''}" type="button" data-dataset-chip="${idx}">
          <span class="dataset-chip-name">${escapeHtml(item.dataset_name || `Dataset ${idx + 1}`)}</span>
          <span class="dataset-chip-meta">${escapeHtml(item.kpis?.total_cases || 0)} cases · ${formatPct(item.kpis?.deviation_rate || 0)} deviation</span>
        </button>`).join('')}
    </div>`;

  Array.from(document.querySelectorAll('[data-dataset-chip]')).forEach((btn) => {
    btn.addEventListener('click', () => {
      const nextIndex = Number(btn.dataset.datasetChip || 0);
      if (Number.isNaN(nextIndex) || nextIndex === activeDatasetIndex) return;
      activeDatasetIndex = nextIndex;
      renderActiveDataset();
      activateTab('overview');
    });
  });
}


function activateTab(name) {
  els.tabButtons.forEach((btn) => btn.classList.toggle('active', btn.dataset.tab === name));
  els.tabPanels.forEach((panel) => panel.classList.toggle('active', panel.dataset.tabPanel === name));
}

function showStory(index) {
  els.storyCards.forEach((card, i) => card.classList.toggle('active', i === index));
  els.storyDots.forEach((dot, i) => dot.classList.toggle('active', i === index));
}

function bootStoryCarousel() {
  if (storyTimer) clearInterval(storyTimer);
  let idx = els.storyCards.findIndex((card) => card.classList.contains('active'));
  if (idx < 0) idx = 0;
  storyTimer = setInterval(() => {
    idx = (idx + 1) % els.storyCards.length;
    showStory(idx);
  }, 6200);
}

function renderKPIs(kpis) {
  const cards = [
    { label: 'Cases', value: kpis.total_cases, icon: '◎', note: 'Unique process instances' },
    { label: 'Events', value: kpis.total_events, icon: '✦', note: 'Tracked workflow events' },
    { label: 'Median steps', value: Number(kpis.median_steps).toFixed(1), icon: '↦', note: 'Typical path length' },
    { label: 'Dominant path share', value: formatPct(kpis.dominant_path_share), icon: '◌', note: 'Share on primary route' },
    { label: 'Deviation rate', value: formatPct(kpis.deviation_rate), icon: '△', note: 'Cases outside dominant path' },
    { label: 'SLA breach rate', value: formatPct(kpis.sla_breach_rate), icon: '⏱', note: 'Cases over SLA threshold' },
  ];

  els.kpiGrid.innerHTML = cards.map((card) => `
    <article class="kpi-card">
      <div class="kpi-label"><span>${escapeHtml(card.label)}</span><span class="kpi-icon">${escapeHtml(card.icon)}</span></div>
      <strong>${escapeHtml(card.value)}</strong>
      <small>${escapeHtml(card.note)}</small>
    </article>`).join('');
}

function renderProcessMap(dominantPath, flowEdges, variants) {
  const steps = dominantPath || [];
  if (!steps.length) {
    els.processMapSvg.innerHTML = '<div class="muted">No dominant path available.</div>';
    return;
  }

  const width = Math.max(1260, 280 + steps.length * 230);
  const height = 360;
  const baselineY = 190;
  const startX = 120;
  const gap = (width - 240) / Math.max(1, steps.length - 1);
  const baselineCounts = steps.slice(0, -1).map((step, idx) => {
    const match = (flowEdges || []).find((edge) => edge.source === step && edge.target === steps[idx + 1]);
    return match ? Number(match.count || 0) : 0;
  });

  let svg = `
    <div class="map-shell">
      <div class="map-scroll">
        <svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Workflow process map">
          <defs>
            <linearGradient id="baselineGrad" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stop-color="#7a6cff"/>
              <stop offset="50%" stop-color="#35d6cb"/>
              <stop offset="100%" stop-color="#73ef8a"/>
            </linearGradient>
          </defs>
          <rect x="24" y="24" width="${width - 48}" height="${height - 48}" rx="28" fill="rgba(6,11,36,.24)" stroke="rgba(255,255,255,.08)"/>
          <text x="56" y="64" fill="#e6ecff" font-size="20" font-weight="800">Primary workflow baseline</text>
          <text x="56" y="94" fill="#a9b5dc" font-size="14" font-weight="600">Dominant path shown with directional arrows. Alternate variants are summarized below for cleaner reading.</text>
  `;

  for (let i = 0; i < steps.length - 1; i += 1) {
    const x1 = startX + i * gap;
    const x2 = startX + (i + 1) * gap;
    const count = baselineCounts[i] || 0;
    const mx = (x1 + x2) / 2;
    svg += `
      <path d="M ${x1 + 58} ${baselineY} C ${x1 + 118} ${baselineY - 10}, ${x2 - 118} ${baselineY - 10}, ${x2 - 58} ${baselineY}" stroke="url(#baselineGrad)" stroke-width="8" fill="none" stroke-linecap="round" opacity="0.95"/>
      <path d="M ${mx - 10} ${baselineY - 10} L ${mx + 2} ${baselineY} L ${mx - 10} ${baselineY + 10}" stroke="rgba(243,246,255,.92)" stroke-width="3.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
      <g class="process-count-badge" transform="translate(${mx}, ${baselineY - 98})">
        <rect x="-22" y="-14" width="44" height="28" rx="14" fill="rgba(9,15,40,.92)" stroke="rgba(255,255,255,.12)"/>
        <text text-anchor="middle" y="6" fill="#f2f6ff" font-size="14" font-weight="800">${count}</text>
      </g>`;
  }

  steps.forEach((step, idx) => {
    const x = startX + idx * gap;
    const accent = palette[idx % palette.length];
    const subtitle = idx === 0 ? 'Intake' : idx === steps.length - 1 ? 'Outcome' : 'Processing stage';
    svg += `
      <g>
        <circle cx="${x}" cy="${baselineY}" r="44" fill="${accent}18" stroke="${accent}" stroke-width="4"/>
        <circle cx="${x}" cy="${baselineY}" r="22" fill="rgba(9,15,40,.96)"/>
        <text x="${x}" y="${baselineY + 6}" fill="#ffffff" font-size="20" font-weight="800" text-anchor="middle">${idx + 1}</text>
        <text x="${x}" y="${baselineY + 92}" fill="#f3f6ff" font-size="24" font-weight="800" text-anchor="middle">${escapeHtml(step)}</text>
        <text x="${x}" y="${baselineY + 120}" fill="#aab4d9" font-size="14" font-weight="700" text-anchor="middle">${subtitle}</text>
      </g>`;
  });

  svg += `</svg></div>`;
  const alternate = (variants || []).filter((v) => String(v.variant) !== steps.join(' -> ')).slice(0, 6);
  svg += `<div class="route-list">`;
  if (!alternate.length) {
    svg += `<div class="route-card"><div><strong>No alternate routes above threshold</strong><div class="muted">The dominant path fully explains the observed cases.</div></div></div>`;
  } else {
    alternate.forEach((item, idx) => {
      svg += `
        <div class="route-card">
          <div>
            <strong>Alternate route ${idx + 1}</strong>
            <div class="muted">${escapeHtml(item.variant)}</div>
          </div>
          <div>
            <div class="muted" style="margin-bottom:8px;text-align:right">${formatPct(item.share)} · ${escapeHtml(item.count)} cases</div>
            <div class="route-bar"><span style="width:${Math.max(8, Number(item.share || 0) * 100)}%"></span></div>
          </div>
        </div>`;
    });
  }
  svg += `</div></div>`;
  els.processMapSvg.innerHTML = svg;
}

function renderInsightSlides(data) {
  const slides = [
    {
      title: 'Deviation pressure',
      body: `${formatPct(data.kpis.deviation_rate)} of cases diverged from the dominant path. ${data.anomaly_summary?.top_reasons?.[0]?.reason || 'Deviation mix available below'} leads the mix.`,
      meta: `${data.anomaly_summary?.total_deviations || 0} flagged cases`,
    },
    {
      title: 'Stage bottleneck',
      body: `${data.stage_bottlenecks?.[0]?.activity || 'Investigate'} has the highest p90 dwell time at ${Number(data.stage_bottlenecks?.[0]?.p90_duration_hours || 0).toFixed(1)} hours.`,
      meta: `${data.stage_bottlenecks?.[0]?.occurrences || 0} stage occurrences`,
    },
    {
      title: 'Handoff risk',
      body: `${data.handoff_risks?.[0]?.from || '—'} → ${data.handoff_risks?.[0]?.to || '—'} is the riskiest handoff with ${Number(data.handoff_risks?.[0]?.avg_following_duration_hours || 0).toFixed(1)} downstream hours on average.`,
      meta: `${data.handoff_risks?.[0]?.handoff_count || 0} transitions`,
    },
    {
      title: 'Primary route share',
      body: `The dominant path captures ${formatPct(data.kpis.dominant_path_share)} of all cases across the uploaded workflow.`,
      meta: `${data.kpis.total_cases || 0} total cases`,
    },
    {
      title: 'SLA exposure',
      body: `${formatPct(data.kpis.sla_breach_rate)} of cases exceeded the SLA threshold of ${Number(els.slaHours.value || 72).toFixed(0)} hours.`,
      meta: `${data.deviation_cases?.filter((x) => String(x.reason).includes('SLA breach')).length || 0} SLA breach cases`,
    },
  ];

  els.insightSlides.innerHTML = `
    <div class="insight-viewport">
      ${slides.map((slide, idx) => `
        <article class="insight-card ${idx === 0 ? 'active' : ''}" data-insight-card>
          <h4>${escapeHtml(slide.title)}</h4>
          <p>${escapeHtml(slide.body)}</p>
          <div class="insight-meta">${escapeHtml(slide.meta)}</div>
        </article>`).join('')}
      <div class="insight-dots">
        ${slides.map((_, idx) => `<button class="insight-dot ${idx === 0 ? 'active' : ''}" data-insight-dot="${idx}" aria-label="Insight ${idx + 1}"></button>`).join('')}
      </div>
    </div>`;

  const cards = Array.from(document.querySelectorAll('[data-insight-card]'));
  const dots = Array.from(document.querySelectorAll('[data-insight-dot]'));
  const setInsight = (index) => {
    insightIndex = index;
    cards.forEach((card, idx) => card.classList.toggle('active', idx === index));
    dots.forEach((dot, idx) => dot.classList.toggle('active', idx === index));
  };
  const bootInsights = () => {
    if (insightTimer) clearInterval(insightTimer);
    insightTimer = setInterval(() => setInsight((insightIndex + 1) % cards.length), 8200);
  };
  dots.forEach((dot) => dot.addEventListener('click', () => { setInsight(Number(dot.dataset.insightDot)); bootInsights(); }));
  setInsight(0);
  bootInsights();
}

function renderRecommendations(items, data) {
  const recommendations = [...(items || [])];
  if (data?.common_variants?.[1]) {
    recommendations.push(`Variant ${data.common_variants[1].variant} accounts for ${formatPct(data.common_variants[1].share)} of cases and deserves a dedicated review path.`);
  }
  if (data?.anomaly_summary?.longest_cases?.[0]) {
    recommendations.push(`Investigate ${data.anomaly_summary.longest_cases[0].case_id} as a benchmark long-running case for root-cause analysis.`);
  }
  els.recommendationsList.innerHTML = recommendations.map((item) => `<li>${escapeHtml(item)}</li>`).join('');
}

function renderDeviationDonut(summary) {
  const reasons = summary?.top_reasons || [];
  let current = 0;
  const segments = reasons.map((item, idx) => {
    const share = Number(item.share || 0);
    const next = current + share * 100;
    const segment = { ...item, color: palette[idx % palette.length], start: current, end: next };
    current = next;
    return segment;
  });
  const stops = segments.length ? segments.map((s) => `${s.color} ${s.start.toFixed(1)}% ${s.end.toFixed(1)}%`).join(', ') : 'rgba(255,255,255,.14) 0 100%';
  const legend = segments.map((item) => `
    <div class="legend-item">
      <div class="legend-left">
        <span class="legend-swatch" style="background:${item.color}"></span>
        <div class="legend-copy">
          <span class="legend-title">${escapeHtml(item.reason)}</span>
          <span class="legend-sub">${formatPct(item.share)} of flagged cases</span>
        </div>
      </div>
      <strong>${escapeHtml(item.count)}</strong>
    </div>`).join('');

  els.deviationDonut.innerHTML = `
    <div class="donut-layout">
      <div class="donut-chart" style="background: conic-gradient(${stops});">
        <div class="donut-center"><div><strong>${summary?.total_deviations || 0}</strong><span>flagged cases</span></div></div>
      </div>
      <div class="legend-list">${legend || '<div class="muted">No deviation reasons.</div>'}</div>
    </div>`;
}

function renderVariantCards(variants) {
  els.variantCards.innerHTML = `<div class="variant-list">${(variants || []).slice(0, 6).map((item, idx) => `
    <article class="variant-card">
      <div class="variant-top"><div><strong>Route ${idx + 1}</strong><div class="variant-path">${escapeHtml(item.variant)}</div></div><div>${formatPct(item.share)}</div></div>
      <div class="variant-bar"><span style="width:${Math.max(8, Number(item.share || 0) * 100)}%"></span></div>
    </article>`).join('')}</div>`;
}

function renderAnomalySummary(summary) {
  const list = (summary?.top_reasons || []).map((item, idx) => `
    <div class="metric-item">
      <div class="bar-row"><strong>${escapeHtml(item.reason)}</strong><span>${formatPct(item.share)}</span></div>
      <div class="muted">${escapeHtml(item.count)} cases</div>
      <div class="progress-bar"><span style="width:${Math.max(8, Number(item.share || 0) * 100)}%; background:${palette[idx % palette.length]}"></span></div>
    </div>`).join('');
  const longest = (summary?.longest_cases || []).slice(0, 3).map((item) => `
    <div class="longest-item">
      <div class="longest-top"><span>${escapeHtml(item.case_id)}</span><span>${Number(item.duration_hours || 0).toFixed(1)}h</span></div>
      <div class="muted">${escapeHtml(item.variant)}</div>
    </div>`).join('');
  els.anomalySummary.innerHTML = `
    <div class="metric-item">
      <div class="bar-row"><strong>Total deviations</strong><span>${summary?.total_deviations || 0}</span></div>
      <div class="muted">Flagged cases across all categories</div>
      <div class="progress-bar"><span style="width:${Math.max(10, (summary?.total_deviations || 0) * 12)}%"></span></div>
    </div>
    <div class="metric-list">${list || '<div class="muted">No anomaly reasons.</div>'}</div>
    <div class="longest-list">${longest}</div>`;
}

function renderStageBars(rows) {
  const max = Math.max(1, ...(rows || []).map((row) => Number(row.p90_duration_hours || 0)));
  els.stageBars.innerHTML = (rows || []).slice(0, 6).map((row) => `
    <div class="stage-bar">
      <strong>${escapeHtml(row.activity)}</strong>
      <div class="bar-track"><span style="width:${Math.max(8, (Number(row.p90_duration_hours || 0) / max) * 100)}%"></span></div>
      <span>${Number(row.p90_duration_hours || 0).toFixed(1)}h</span>
    </div>`).join('');
}

function renderHandoffNetwork(rows) {
  const pairs = rows || [];
  if (!pairs.length) {
    els.handoffNetwork.innerHTML = '<div class="muted">No cross-team handoffs found.</div>';
    return;
  }
  const width = 1320;
  const height = 720;
  const positions = {
    Support: { x: 180, y: 360 },
    Operations: { x: 500, y: 210 },
    Manager: { x: 920, y: 210 },
    Lead: { x: 520, y: 540 },
    Portal: { x: 960, y: 520 },
  };
  const nodes = [...new Set(pairs.flatMap((item) => [item.from, item.to]))].map((name, idx) => ({
    name,
    x: positions[name]?.x || 180 + idx * 180,
    y: positions[name]?.y || 260,
    color: palette[idx % palette.length],
  }));
  const map = Object.fromEntries(nodes.map((node) => [node.name, node]));
  const maxCount = Math.max(1, ...pairs.map((item) => Number(item.handoff_count || 0)));

  const links = pairs.slice(0, 7).map((item, idx) => {
    const from = map[item.from];
    const to = map[item.to];
    if (!from || !to) return '';
    const stroke = 8 + (Number(item.handoff_count || 0) / maxCount) * 16;
    const curve = idx % 2 === 0 ? -60 : 60;
    const midX = (from.x + to.x) / 2;
    const midY = (from.y + to.y) / 2 + curve;
    return `
      <g>
        <path d="M ${from.x} ${from.y} Q ${midX} ${midY} ${to.x} ${to.y}" stroke="rgba(234,239,255,.32)" stroke-width="${stroke}" stroke-linecap="round" fill="none"/>
        <g transform="translate(${midX}, ${midY})">
          <circle r="18" fill="rgba(8,15,40,.96)" stroke="rgba(255,255,255,.16)"/>
          <text text-anchor="middle" y="6" fill="#edf3ff" font-size="14" font-weight="800">${item.handoff_count}</text>
        </g>
      </g>`;
  }).join('');

  const nodeSvg = nodes.map((node) => `
    <g>
      <circle cx="${node.x}" cy="${node.y}" r="58" fill="${node.color}14" stroke="${node.color}" stroke-width="4"/>
      <circle cx="${node.x}" cy="${node.y}" r="30" fill="rgba(9,15,40,.97)"/>
      <circle cx="${node.x}" cy="${node.y}" r="9" fill="${node.color}"/>
      <text x="${node.x}" y="${node.y + 88}" text-anchor="middle" fill="#ffffff" font-size="28" font-weight="800">${escapeHtml(node.name)}</text>
      <text x="${node.x}" y="${node.y + 116}" text-anchor="middle" fill="#aab4d9" font-size="16" font-weight="700">Team node</text>
    </g>`).join('');

  els.handoffNetwork.innerHTML = `
    <div class="map-shell">
      <div class="network-scroll">
        <svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Handoff network graph">
          <rect x="24" y="24" width="${width - 48}" height="${height - 48}" rx="32" fill="rgba(7,13,38,.22)" stroke="rgba(255,255,255,.08)"/>
          <text x="58" y="64" fill="#eef3ff" font-size="22" font-weight="800">Cross-team handoff network</text>
          <text x="58" y="94" fill="#a9b5dc" font-size="15" font-weight="600">Thicker links represent more frequent transitions. Count bubbles show observed handoffs.</text>
          ${links}
          ${nodeSvg}
        </svg>
      </div>
    </div>`;
}

function renderTimeline(items) {
  if (!items || !items.length) {
    els.timelineCards.innerHTML = '<div class="muted">No long-running cases available.</div>';
    return;
  }
  els.timelineCards.innerHTML = `<div class="timeline-list">${items.map((item) => `
    <article class="timeline-card">
      <div class="timeline-top"><span>${escapeHtml(item.case_id)}</span><span>${Number(item.duration_hours || 0).toFixed(1)}h</span></div>
      <div class="timeline-steps">${String(item.variant || '').split(' -> ').map((step) => `<span>${escapeHtml(step)}</span>`).join('')}</div>
    </article>`).join('')}</div>`;
}

function splitListLike(value) {
  if (Array.isArray(value)) return value.filter(Boolean);
  if (!value || value === '—') return [];
  return String(value).split(',').map((part) => part.trim()).filter(Boolean);
}

function formatListChips(items, cls) {
  const list = splitListLike(items);
  if (!list.length) return '<span class="muted">—</span>';
  return list.map((item) => `<span class="${cls}">${escapeHtml(item)}</span>`).join('');
}

function renderDeviationCards(items) {
  if (!items || !items.length) {
    els.deviationCases.innerHTML = '<div class="muted">No deviation cases found.</div>';
    return;
  }
  els.deviationCases.innerHTML = `<div class="case-grid">${items.slice(0, 6).map((item) => `
    <article class="case-card">
      <div class="case-top">
        <div class="case-heading">
          <div class="case-id">${escapeHtml(item.case_id)}</div>
          <div class="muted">${Number(item.duration_hours || 0).toFixed(1)}h · ${escapeHtml(item.steps)} steps</div>
        </div>
      </div>
      <div class="case-chip-row case-reasons">${formatListChips(item.reason, 'reason-chip single-line')}</div>
      <div class="case-section"><span class="mini-label">Actors</span><div class="case-chip-row case-actors">${formatListChips(item.actors, 'actor-chip')}</div></div>
      <div class="case-meta-grid">
        <div><span class="mini-label">Missing</span><div class="case-chip-row case-actors">${formatListChips(item.missing_steps, 'neutral-chip')}</div></div>
        <div><span class="mini-label">Extra</span><div class="case-chip-row case-actors">${formatListChips(item.extra_steps, 'neutral-chip')}</div></div>
      </div>
    </article>`).join('')}</div>`;
}


function renderCompareSection(analyses) {
  const items = analyses || [];
  if (!items.length) {
    els.compareCards.innerHTML = '<div class="muted">Upload multiple CSV or Excel files together to compare workflows.</div>';
    els.compareTable.innerHTML = '<div class="muted">No comparison data yet.</div>';
    return;
  }
  els.compareCards.innerHTML = `<div class="compare-grid">${items.map((item, idx) => `
    <article class="compare-card ${idx === activeDatasetIndex ? 'active' : ''}">
      <div class="compare-card-top">
        <strong>${escapeHtml(item.dataset_name || 'Workflow')}</strong>
        <button class="compare-focus-btn" type="button" data-compare-focus="${idx}">${idx === activeDatasetIndex ? 'Active in main tabs' : 'View in main tabs'}</button>
      </div>
      <div class="compare-kpis">
        <span>Cases <b>${item.kpis.total_cases}</b></span>
        <span>Deviation <b>${formatPct(item.kpis.deviation_rate)}</b></span>
        <span>Dominant path <b>${formatPct(item.kpis.dominant_path_share)}</b></span>
        <span>SLA breach <b>${formatPct(item.kpis.sla_breach_rate)}</b></span>
      </div>
    </article>`).join('')}</div>`;
  els.compareTable.innerHTML = tableFromRows(items, [
    { key: 'dataset_name', label: 'Workflow' },
    { key: 'kpis', label: 'Cases', render: (v) => escapeHtml(v.total_cases) },
    { key: 'kpis', label: 'Events', render: (v) => escapeHtml(v.total_events) },
    { key: 'kpis', label: 'Dominant path share', render: (v) => formatPct(v.dominant_path_share) },
    { key: 'kpis', label: 'Deviation rate', render: (v) => formatPct(v.deviation_rate) },
    { key: 'kpis', label: 'SLA breach rate', render: (v) => formatPct(v.sla_breach_rate) },
  ]);
  Array.from(document.querySelectorAll('[data-compare-focus]')).forEach((btn) => {
    btn.addEventListener('click', () => {
      const nextIndex = Number(btn.dataset.compareFocus || 0);
      if (Number.isNaN(nextIndex)) return;
      activeDatasetIndex = nextIndex;
      renderActiveDataset();
      activateTab('overview');
    });
  });
}

function renderActiveDataset() {
  const data = currentAnalyses[activeDatasetIndex];
  if (!data) return;
  els.emptyState.classList.add('hidden');
  els.results.classList.remove('hidden');
  renderDatasetSwitcher();
  renderKPIs(data.kpis);
  renderProcessMap(data.dominant_path, data.flow_edges, data.common_variants);
  renderInsightSlides(data);
  renderRecommendations(data.recommendations, data);
  renderDeviationDonut(data.anomaly_summary);
  renderVariantCards(data.common_variants);
  renderDeviationCards(data.deviation_cases);
  renderAnomalySummary(data.anomaly_summary);
  renderHandoffNetwork(data.handoff_risks);
  renderStageBars(data.stage_bottlenecks);
  renderTimeline(data.anomaly_summary?.longest_cases || []);

  els.variantsTable.innerHTML = tableFromRows(data.common_variants, [
    { key: 'variant', label: 'Variant' },
    { key: 'count', label: 'Count' },
    { key: 'share', label: 'Share', render: (value) => formatPct(value) },
  ]);
  els.stageBottlenecks.innerHTML = tableFromRows(data.stage_bottlenecks, [
    { key: 'activity', label: 'Stage' },
    { key: 'avg_duration_hours', label: 'Avg hours', render: (v) => Number(v).toFixed(2) },
    { key: 'p90_duration_hours', label: 'P90 hours', render: (v) => Number(v).toFixed(2) },
    { key: 'occurrences', label: 'Occurrences' },
  ]);
  els.flowEdges.innerHTML = tableFromRows(data.flow_edges, [
    { key: 'source', label: 'Source' },
    { key: 'target', label: 'Target' },
    { key: 'count', label: 'Transitions' },
  ]);
  const previewColumns = Object.keys(data.preview_rows?.[0] || {}).map((key) => ({ key, label: key }));
  els.previewTable.innerHTML = previewColumns.length ? tableFromRows(data.preview_rows, previewColumns) : '<div class="muted">No preview rows available.</div>';
  renderCompareSection(currentAnalyses);
  setDatasetLabel(currentAnalyses.length > 1
    ? `${currentAnalyses.length} datasets analyzed, viewing ${data.dataset_name || `Dataset ${activeDatasetIndex + 1}`}`
    : (data.dataset_name || 'Workflow dataset'));
}

function renderData(data, analyses = null) {
  const resolved = Array.isArray(analyses) && analyses.length ? analyses : [data];
  setCurrentAnalyses(resolved, resolved.findIndex((item) => item === data) >= 0 ? resolved.findIndex((item) => item === data) : 0);
  els.emptyState.classList.add('hidden');
  els.results.classList.remove('hidden');
  activateTab('overview');
  renderActiveDataset();
}


async function loadSample() {
  setStatus('Loading demo dataset', 'loading');
  setDatasetLabel('Demo mode: sample_workflow.csv');
  try {
    const res = await fetch('/api/sample');
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'Could not load demo dataset');
    renderData(data);
    setStatus('Demo mode active', 'success');
  } catch (err) {
    setStatus('Failed to load demo dataset', 'error');
    setDatasetLabel(err.message || 'Demo unavailable');
  }
}

async function uploadAndAnalyze(files, mode = 'files') {
  const selected = Array.from(files || []).filter(Boolean);
  if (!selected.length) return;

  const supported = selected.filter((file) => {
    const name = String(file.webkitRelativePath || file.name || '').toLowerCase();
    return [
      '.csv', '.xlsx', '.xls', '.xlsm', '.xltx', '.xltm', '.xes', '.xes.gz', '.zip'
    ].some((suffix) => name.endsWith(suffix));
  });

  if (!supported.length) {
    setStatus('No supported files found', 'error');
    setDatasetLabel('Use CSV, Excel, XES, XES.GZ, or ZIP files.');
    return;
  }

  const label = mode === 'folder'
    ? `${supported.length} supported files found in folder upload`
    : `${supported.length} workflow file${supported.length === 1 ? '' : 's'} selected`;

  setStatus(`Analyzing ${supported.length} workflow file${supported.length === 1 ? '' : 's'}`, 'loading');
  setDatasetLabel(label);

  const form = new FormData();
  supported.forEach((file) => form.append('files', file, file.webkitRelativePath || file.name));
  const params = new URLSearchParams({
    case_id_col: els.caseIdCol.value,
    timestamp_col: els.timestampCol.value,
    activity_col: els.activityCol.value,
    actor_col: els.actorCol.value,
    duration_hours_col: els.durationCol.value,
    status_col: els.statusCol.value,
    variant_support_threshold: els.supportThreshold.value,
    sla_hours: els.slaHours.value,
    top_n_deviations: els.topN.value,
  });

  try {
    const res = await fetch(`/api/analyze-multiple?${params.toString()}`, { method: 'POST', body: form });
    const payload = await res.json();
    if (!res.ok) throw new Error(payload.detail || 'Upload failed');
    const analyses = payload.analyses || [];
    if (!analyses.length) throw new Error('No analyses returned');
    setCurrentAnalyses(analyses, 0);
    renderData(analyses[0], analyses);
    if (analyses.length > 1) {
      activateTab('compare');
      setStatus('Comparison completed', 'success');
    } else {
      setStatus('Analysis completed', 'success');
    }
    if (payload.failures?.length) {
      setDatasetLabel(`${analyses.length} dataset${analyses.length === 1 ? '' : 's'} analyzed, ${payload.failures.length} failed`);
    } else if (analyses.length === 1) {
      setDatasetLabel(analyses[0].dataset_name || supported[0].name);
    } else {
      setDatasetLabel(`${analyses.length} datasets analyzed successfully`);
    }
  } catch (err) {
    setStatus(supported.length > 1 ? 'Comparison failed' : 'Analysis failed', 'error');
    setDatasetLabel(err.message || 'Upload error');
  }
}

els.loadSampleBtn.addEventListener('click', loadSample);
els.loadSampleBtnEmpty.addEventListener('click', loadSample);
els.fileInput.addEventListener('change', (event) => { uploadAndAnalyze(event.target.files, 'files'); event.target.value = ''; });
els.folderInput.addEventListener('change', (event) => { uploadAndAnalyze(event.target.files, 'folder'); event.target.value = ''; });
els.tabButtons.forEach((btn) => btn.addEventListener('click', () => activateTab(btn.dataset.tab)));
els.storyDots.forEach((dot) => dot.addEventListener('click', () => {
  showStory(Number(dot.dataset.storyDot));
  bootStoryCarousel();
}));

showStory(0);
bootStoryCarousel();
