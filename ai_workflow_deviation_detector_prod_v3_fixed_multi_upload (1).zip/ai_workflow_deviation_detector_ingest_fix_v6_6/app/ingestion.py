from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Iterable
from zipfile import BadZipFile, ZipFile
import gzip

import pandas as pd
from fastapi import UploadFile

SUPPORTED_SUFFIXES = (
    ".csv",
    ".xlsx",
    ".xls",
    ".xlsm",
    ".xltx",
    ".xltm",
    ".xes",
    ".xes.gz",
)


@dataclass
class ParsedDataset:
    name: str
    source_path: str
    data: pd.DataFrame


@dataclass
class ParseFailure:
    name: str
    error: str


@dataclass
class ParseBatchResult:
    datasets: list[ParsedDataset]
    failures: list[ParseFailure]


class DatasetParser:
    def __init__(self) -> None:
        self._pm4py_checked = False

    def parse_uploads(self, files: Iterable[UploadFile]) -> ParseBatchResult:
        datasets: list[ParsedDataset] = []
        failures: list[ParseFailure] = []
        for file in files:
            filename = file.filename or "unnamed"
            try:
                raw = file.file.read()
                batch = self.parse_bytes(raw=raw, source_name=filename)
                datasets.extend(batch.datasets)
                failures.extend(batch.failures)
            except Exception as exc:
                failures.append(ParseFailure(name=filename, error=str(exc)))
        return ParseBatchResult(datasets=datasets, failures=failures)

    def parse_bytes(self, raw: bytes, source_name: str) -> ParseBatchResult:
        lower = source_name.lower()
        if lower.endswith(".zip"):
            return self._parse_zip(raw=raw, source_name=source_name)
        try:
            df = self._read_supported_bytes(raw=raw, filename=source_name)
            return ParseBatchResult(datasets=[ParsedDataset(name=Path(source_name).name, source_path=source_name, data=df)], failures=[])
        except Exception as exc:
            return ParseBatchResult(datasets=[], failures=[ParseFailure(name=source_name, error=str(exc))])

    def _parse_zip(self, raw: bytes, source_name: str) -> ParseBatchResult:
        datasets: list[ParsedDataset] = []
        failures: list[ParseFailure] = []
        try:
            with ZipFile(BytesIO(raw)) as archive:
                members = [name for name in archive.namelist() if not name.endswith("/")]
                if not members:
                    return ParseBatchResult(datasets=[], failures=[ParseFailure(name=source_name, error="ZIP archive is empty")])
                for member in members:
                    lower = member.lower()
                    if lower.endswith(".zip"):
                        nested_raw = archive.read(member)
                        nested = self._parse_zip(raw=nested_raw, source_name=f"{source_name}::{member}")
                        datasets.extend(nested.datasets)
                        failures.extend(nested.failures)
                        continue
                    if not lower.endswith(SUPPORTED_SUFFIXES):
                        continue
                    member_name = f"{source_name}::{member}"
                    try:
                        nested_df = self._read_supported_bytes(raw=archive.read(member), filename=member)
                        datasets.append(ParsedDataset(name=Path(member).name, source_path=member_name, data=nested_df))
                    except Exception as exc:
                        failures.append(ParseFailure(name=member_name, error=str(exc)))
        except BadZipFile as exc:
            return ParseBatchResult(datasets=[], failures=[ParseFailure(name=source_name, error=f"Invalid ZIP archive: {exc}")])
        if not datasets and not failures:
            failures.append(ParseFailure(name=source_name, error="ZIP file does not contain a supported CSV, Excel, XES, or XES.GZ file"))
        return ParseBatchResult(datasets=datasets, failures=failures)

    def _read_supported_bytes(self, raw: bytes, filename: str) -> pd.DataFrame:
        lower = filename.lower()
        if lower.endswith(".csv"):
            return self._read_csv_bytes(raw)
        if lower.endswith((".xlsx", ".xls", ".xlsm", ".xltx", ".xltm")):
            return self._read_excel_bytes(raw, filename)
        if lower.endswith((".xes", ".xes.gz")):
            return self._read_xes_bytes(raw, filename)
        raise ValueError("Unsupported file type")

    def _read_csv_bytes(self, raw: bytes) -> pd.DataFrame:
        try:
            return pd.read_csv(BytesIO(raw))
        except UnicodeDecodeError:
            return pd.read_csv(BytesIO(raw), encoding="latin-1")

    def _read_excel_bytes(self, raw: bytes, filename: str) -> pd.DataFrame:
        engine = "openpyxl" if filename.lower().endswith((".xlsx", ".xlsm", ".xltx", ".xltm")) else "xlrd"
        return pd.read_excel(BytesIO(raw), engine=engine)

    def _read_xes_bytes(self, raw: bytes, filename: str) -> pd.DataFrame:
        if filename.lower().endswith(".gz"):
            raw = gzip.decompress(raw)
            filename = filename[:-3]
        try:
            import pm4py
        except ImportError as exc:
            raise RuntimeError("XES support is not installed. Please install pm4py.") from exc

        with TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir) / Path(filename).name
            tmp_path.write_bytes(raw)
            log = pm4py.read_xes(str(tmp_path))
            df = pm4py.convert_to_dataframe(log)

        rename_map = {
            "case:concept:name": "case_id",
            "time:timestamp": "timestamp",
            "concept:name": "activity",
            "org:resource": "actor",
            "lifecycle:transition": "status",
        }
        df = df.rename(columns={k: v for k, v in rename_map.items() if k in df.columns})
        if {"case_id", "timestamp", "activity"}.issubset(df.columns):
            df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
            df = df.sort_values(["case_id", "timestamp", "activity"]).reset_index(drop=True)
            if "actor" not in df.columns:
                df["actor"] = "Unassigned"
            if "duration_hours" not in df.columns:
                df["duration_hours"] = (
                    df.groupby("case_id")["timestamp"].diff().dt.total_seconds().div(3600).fillna(0).clip(lower=0)
                )
            if "status" not in df.columns:
                df["status"] = "in_progress"
                last_indexes = df.groupby("case_id").tail(1).index
                df.loc[last_indexes, "status"] = "closed"
        return df
