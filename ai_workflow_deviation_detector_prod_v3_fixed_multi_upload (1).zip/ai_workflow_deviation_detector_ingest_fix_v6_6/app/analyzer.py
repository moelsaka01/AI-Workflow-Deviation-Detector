from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from statistics import median
from typing import Any

import numpy as np
import pandas as pd

from .schemas import AnalysisConfig, AnalysisResponse, KPIBlock


REQUIRED_COLUMNS = {"case_id", "timestamp", "activity"}

AUTO_COLUMN_ALIASES = {
    "case_id": ["case_id", "case", "caseid", "case id", "trace_id", "traceid", "process_instance", "process instance", "concept:name", "case:concept:name"],
    "timestamp": ["timestamp", "time", "event_time", "event time", "datetime", "time:timestamp"],
    "activity": ["activity", "event", "event_name", "event name", "task", "step", "concept:name"],
    "actor": ["actor", "resource", "owner", "user", "assignee", "org:resource"],
    "duration_hours": ["duration_hours", "duration", "duration_h", "hours", "elapsed_hours", "sojourn_hours"],
    "status": ["status", "state", "result", "lifecycle:transition"],
}


@dataclass
class CaseSummary:
    case_id: str
    activities: list[str]
    actors: list[str]
    duration_hours: float
    total_steps: int
    variant: str
    is_deviation: bool
    is_sla_breach: bool
    deviation_reason: str


class WorkflowAnalyzer:
    def __init__(self, config: AnalysisConfig):
        self.config = config

    def _infer_column(self, df: pd.DataFrame, requested: str | None, canonical: str) -> str | None:
        if requested and requested in df.columns:
            return requested
        normalized_lookup = {str(col).strip().lower(): col for col in df.columns}
        for alias in AUTO_COLUMN_ALIASES.get(canonical, []):
            if alias.lower() in normalized_lookup:
                return str(normalized_lookup[alias.lower()])
        return None

    def _normalize_columns(self, df: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, str]]:
        inferred = {
            "case_id": self._infer_column(df, self.config.case_id_col, "case_id"),
            "timestamp": self._infer_column(df, self.config.timestamp_col, "timestamp"),
            "activity": self._infer_column(df, self.config.activity_col, "activity"),
            "actor": self._infer_column(df, self.config.actor_col, "actor"),
            "duration_hours": self._infer_column(df, self.config.duration_hours_col, "duration_hours"),
            "status": self._infer_column(df, self.config.status_col, "status"),
        }
        rename_map = {source: target for target, source in inferred.items() if source and source != target}
        normalized = df.rename(columns=rename_map).copy()
        missing = REQUIRED_COLUMNS - set(normalized.columns)
        if missing:
            raise ValueError(f"Missing required columns after mapping: {sorted(missing)}")

        normalized["timestamp"] = pd.to_datetime(normalized["timestamp"], errors="coerce", utc=True)
        if normalized["timestamp"].isna().any():
            raise ValueError("Some timestamp values could not be parsed.")

        if "actor" not in normalized.columns:
            normalized["actor"] = "Unassigned"
        normalized["actor"] = normalized["actor"].fillna("Unassigned").astype(str)

        if "duration_hours" not in normalized.columns:
            normalized["duration_hours"] = 1.0
        normalized["duration_hours"] = pd.to_numeric(normalized["duration_hours"], errors="coerce").fillna(1.0)

        if "status" not in normalized.columns:
            normalized["status"] = "completed"
        normalized["status"] = normalized["status"].fillna("completed").astype(str)

        normalized["case_id"] = normalized["case_id"].astype(str)
        normalized["activity"] = normalized["activity"].astype(str)
        normalized = normalized.sort_values(["case_id", "timestamp", "activity"]).reset_index(drop=True)
        detected_mapping = {target: source for target, source in inferred.items() if source}
        return normalized, detected_mapping

    def analyze(self, df: pd.DataFrame) -> AnalysisResponse:
        df, detected_mapping = self._normalize_columns(df)
        case_summaries = self._build_case_summaries(df)
        variants = Counter(summary.variant for summary in case_summaries)
        dominant_variant, dominant_count = variants.most_common(1)[0]
        dominant_path = dominant_variant.split(" -> ")

        deviation_cases = self._build_deviation_cases(case_summaries, dominant_path)
        stage_bottlenecks = self._stage_bottlenecks(df)
        handoff_risks = self._handoff_risks(df)
        flow_edges = self._flow_edges(df)
        anomaly_summary = self._anomaly_summary(case_summaries)
        recommendations = self._recommendations(case_summaries, stage_bottlenecks, handoff_risks)
        preview_rows = df.head(12).replace({np.nan: None}).to_dict(orient="records")

        total_cases = len(case_summaries)
        total_events = len(df)
        dominant_path_share = dominant_count / total_cases if total_cases else 0.0
        deviation_rate = sum(s.is_deviation for s in case_summaries) / total_cases if total_cases else 0.0
        sla_breach_rate = sum(s.is_sla_breach for s in case_summaries) / total_cases if total_cases else 0.0
        median_steps = float(median(s.total_steps for s in case_summaries)) if case_summaries else 0.0
        average_cycle_time_hours = float(np.mean([s.duration_hours for s in case_summaries])) if case_summaries else 0.0

        common_variants = [
            {
                "variant": variant,
                "count": count,
                "share": round(count / total_cases, 4),
            }
            for variant, count in variants.most_common(8)
        ]

        return AnalysisResponse(
            kpis=KPIBlock(
                total_cases=total_cases,
                total_events=total_events,
                median_steps=median_steps,
                average_cycle_time_hours=round(average_cycle_time_hours, 2),
                dominant_path_share=round(dominant_path_share, 4),
                deviation_rate=round(deviation_rate, 4),
                sla_breach_rate=round(sla_breach_rate, 4),
            ),
            dominant_path=dominant_path,
            common_variants=common_variants,
            deviation_cases=deviation_cases[: self.config.top_n_deviations],
            stage_bottlenecks=stage_bottlenecks,
            handoff_risks=handoff_risks,
            flow_edges=flow_edges,
            transition_probabilities=self._transition_probabilities(df),
            recommendations=recommendations,
            anomaly_summary=anomaly_summary,
            preview_rows=preview_rows,
            detected_mapping=detected_mapping,
        )

    def _build_case_summaries(self, df: pd.DataFrame) -> list[CaseSummary]:
        case_summaries: list[CaseSummary] = []
        grouped = df.groupby("case_id", sort=False)
        variants = Counter(" -> ".join(group["activity"].tolist()) for _, group in grouped)
        total_cases = len(grouped)
        support_cutoff = max(1, int(np.ceil(self.config.variant_support_threshold * total_cases)))

        for case_id, group in grouped:
            activities = group["activity"].tolist()
            actors = group["actor"].tolist()
            duration_hours = float(group["duration_hours"].sum())
            variant = " -> ".join(activities)
            uncommon_variant = variants[variant] < support_cutoff
            repeated_stage = len(activities) != len(set(activities))
            skipped_finish = "Closed" not in activities and "Resolved" not in activities
            is_sla_breach = duration_hours > self.config.sla_hours
            is_deviation = uncommon_variant or repeated_stage or skipped_finish or is_sla_breach

            reasons = []
            if uncommon_variant:
                reasons.append("low-support path")
            if repeated_stage:
                reasons.append("rework loop")
            if skipped_finish:
                reasons.append("unfinished termination")
            if is_sla_breach:
                reasons.append("SLA breach")

            case_summaries.append(
                CaseSummary(
                    case_id=case_id,
                    activities=activities,
                    actors=actors,
                    duration_hours=round(duration_hours, 2),
                    total_steps=len(activities),
                    variant=variant,
                    is_deviation=is_deviation,
                    is_sla_breach=is_sla_breach,
                    deviation_reason=", ".join(reasons) if reasons else "on happy path",
                )
            )
        return case_summaries

    def _build_deviation_cases(self, case_summaries: list[CaseSummary], dominant_path: list[str]) -> list[dict[str, Any]]:
        rows = []
        dominant_set = set(dominant_path)
        for summary in case_summaries:
            if not summary.is_deviation:
                continue
            missing_steps = [step for step in dominant_path if step not in summary.activities]
            extra_steps = [step for step in summary.activities if step not in dominant_set]
            rows.append(
                {
                    "case_id": summary.case_id,
                    "variant": summary.variant,
                    "duration_hours": summary.duration_hours,
                    "steps": summary.total_steps,
                    "reason": summary.deviation_reason,
                    "missing_steps": missing_steps,
                    "extra_steps": extra_steps,
                    "actors": sorted(set(summary.actors)),
                }
            )
        rows.sort(key=lambda x: ("SLA breach" not in x["reason"], -x["duration_hours"], -x["steps"]))
        return rows

    def _stage_bottlenecks(self, df: pd.DataFrame) -> list[dict[str, Any]]:
        stage_stats = (
            df.groupby("activity")
            .agg(
                avg_duration_hours=("duration_hours", "mean"),
                p90_duration_hours=("duration_hours", lambda s: float(np.percentile(s, 90))),
                occurrences=("activity", "count"),
            )
            .reset_index()
        )
        stage_stats["avg_duration_hours"] = stage_stats["avg_duration_hours"].round(2)
        stage_stats["p90_duration_hours"] = stage_stats["p90_duration_hours"].round(2)
        stage_stats = stage_stats.sort_values(["p90_duration_hours", "avg_duration_hours"], ascending=False)
        return stage_stats.head(8).to_dict(orient="records")

    def _handoff_risks(self, df: pd.DataFrame) -> list[dict[str, Any]]:
        transitions: defaultdict[tuple[str, str], dict[str, Any]] = defaultdict(lambda: {"count": 0, "duration": 0.0, "cases": set()})
        for _, group in df.groupby("case_id", sort=False):
            rows = group.reset_index(drop=True)
            for idx in range(1, len(rows)):
                prev = rows.iloc[idx - 1]
                cur = rows.iloc[idx]
                key = (str(prev["actor"]), str(cur["actor"]))
                transitions[key]["count"] += 1
                transitions[key]["duration"] += float(cur["duration_hours"])
                transitions[key]["cases"].add(str(cur["case_id"]))

        ranked = []
        for (from_actor, to_actor), info in transitions.items():
            if from_actor == to_actor:
                continue
            ranked.append(
                {
                    "from": from_actor,
                    "to": to_actor,
                    "handoff_count": info["count"],
                    "avg_following_duration_hours": round(info["duration"] / max(info["count"], 1), 2),
                    "affected_cases": len(info["cases"]),
                }
            )
        ranked.sort(key=lambda x: (x["avg_following_duration_hours"], x["handoff_count"]), reverse=True)
        return ranked[:8]

    def _flow_edges(self, df: pd.DataFrame) -> list[dict[str, Any]]:
        edge_counter: Counter[tuple[str, str]] = Counter()
        for _, group in df.groupby("case_id", sort=False):
            activities = group["activity"].tolist()
            for src, dst in zip(activities, activities[1:]):
                edge_counter[(src, dst)] += 1
        edges = [
            {"source": source, "target": target, "count": count}
            for (source, target), count in edge_counter.most_common(20)
        ]
        return edges

    def _transition_probabilities(self, df: pd.DataFrame) -> list[dict[str, Any]]:
        edge_counter: Counter[tuple[str, str]] = Counter()
        outgoing_counter: Counter[str] = Counter()
        for _, group in df.groupby("case_id", sort=False):
            activities = group["activity"].tolist()
            for src, dst in zip(activities, activities[1:]):
                edge_counter[(src, dst)] += 1
                outgoing_counter[src] += 1
        rows = []
        for (source, target), count in edge_counter.items():
            probability = count / max(1, outgoing_counter[source])
            rows.append({"source": source, "target": target, "count": count, "probability": round(probability, 4)})
        rows.sort(key=lambda item: (item["source"], -item["probability"], -item["count"], item["target"]))
        return rows[:30]

    def _anomaly_summary(self, case_summaries: list[CaseSummary]) -> dict[str, Any]:
        total = len(case_summaries)
        deviations = [s for s in case_summaries if s.is_deviation]
        reason_counter = Counter()
        for summary in deviations:
            for reason in [r.strip() for r in summary.deviation_reason.split(",") if r.strip()]:
                reason_counter[reason] += 1
        return {
            "total_deviations": len(deviations),
            "top_reasons": [
                {"reason": reason, "count": count, "share": round(count / max(1, total), 4)}
                for reason, count in reason_counter.most_common(6)
            ],
            "longest_cases": [
                {
                    "case_id": summary.case_id,
                    "duration_hours": summary.duration_hours,
                    "variant": summary.variant,
                }
                for summary in sorted(case_summaries, key=lambda s: s.duration_hours, reverse=True)[:5]
            ],
        }

    def _recommendations(
        self,
        case_summaries: list[CaseSummary],
        stage_bottlenecks: list[dict[str, Any]],
        handoff_risks: list[dict[str, Any]],
    ) -> list[str]:
        total_cases = max(1, len(case_summaries))
        deviation_rate = sum(s.is_deviation for s in case_summaries) / total_cases
        sla_rate = sum(s.is_sla_breach for s in case_summaries) / total_cases
        recs = []
        if deviation_rate > 0.25:
            recs.append("Standardize intake and approval decision points, the workflow shows a high deviation rate from the dominant path.")
        if sla_rate > 0.2:
            recs.append("Introduce escalation triggers for long-running cases, SLA breaches are materially affecting throughput.")
        if stage_bottlenecks:
            top_stage = stage_bottlenecks[0]
            recs.append(
                f"Review stage '{top_stage['activity']}', it has the highest p90 dwell time and is the most likely bottleneck."
            )
        if handoff_risks:
            top_handoff = handoff_risks[0]
            recs.append(
                f"Reduce cross-team transfers from {top_handoff['from']} to {top_handoff['to']}, these handoffs are followed by the slowest downstream execution."
            )
        if not recs:
            recs.append("The workflow is stable overall, focus on monitoring for freshness and edge-case drift over time.")
        return recs[:5]
