from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class AnalysisConfig(BaseModel):
    case_id_col: str = Field(default="case_id")
    timestamp_col: str = Field(default="timestamp")
    activity_col: str = Field(default="activity")
    actor_col: str | None = Field(default="actor")
    duration_hours_col: str | None = Field(default="duration_hours")
    status_col: str | None = Field(default="status")
    variant_support_threshold: float = Field(default=0.15, ge=0.01, le=1.0)
    sla_hours: float = Field(default=72.0, gt=0)
    top_n_deviations: int = Field(default=10, ge=1, le=50)


class KPIBlock(BaseModel):
    total_cases: int
    total_events: int
    median_steps: float
    average_cycle_time_hours: float
    dominant_path_share: float
    deviation_rate: float
    sla_breach_rate: float


class AnalysisResponse(BaseModel):
    kpis: KPIBlock
    dominant_path: list[str]
    common_variants: list[dict[str, Any]]
    deviation_cases: list[dict[str, Any]]
    stage_bottlenecks: list[dict[str, Any]]
    handoff_risks: list[dict[str, Any]]
    flow_edges: list[dict[str, Any]]
    transition_probabilities: list[dict[str, Any]]
    recommendations: list[str]
    anomaly_summary: dict[str, Any]
    preview_rows: list[dict[str, Any]]
    detected_mapping: dict[str, str]


class ParseFailureResponse(BaseModel):
    name: str
    error: str


class MultiAnalysisResponse(BaseModel):
    analyses: list[dict[str, Any]]
    failures: list[ParseFailureResponse] = Field(default_factory=list)
