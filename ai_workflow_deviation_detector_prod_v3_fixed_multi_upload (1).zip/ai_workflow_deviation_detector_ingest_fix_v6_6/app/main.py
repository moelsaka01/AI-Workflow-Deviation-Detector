from __future__ import annotations

from pathlib import Path

import pandas as pd
from fastapi import FastAPI, File, HTTPException, Query, Request, UploadFile
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .analyzer import WorkflowAnalyzer
from .ingestion import DatasetParser
from .schemas import AnalysisConfig

BASE_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = BASE_DIR / "static"
TEMPLATES_DIR = BASE_DIR / "templates"
SAMPLE_DATA = BASE_DIR / "data" / "sample_workflow.csv"

app = FastAPI(title="AI Workflow Deviation Detector", version="2.0.0")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))
parser = DatasetParser()


def build_config(
    case_id_col: str = "case_id",
    timestamp_col: str = "timestamp",
    activity_col: str = "activity",
    actor_col: str = "actor",
    duration_hours_col: str = "duration_hours",
    status_col: str = "status",
    variant_support_threshold: float = 0.15,
    sla_hours: float = 72.0,
    top_n_deviations: int = 10,
) -> AnalysisConfig:
    return AnalysisConfig(
        case_id_col=case_id_col,
        timestamp_col=timestamp_col,
        activity_col=activity_col,
        actor_col=actor_col or None,
        duration_hours_col=duration_hours_col or None,
        status_col=status_col or None,
        variant_support_threshold=variant_support_threshold,
        sla_hours=sla_hours,
        top_n_deviations=top_n_deviations,
    )


def _analyze_batch(files: list[UploadFile], config: AnalysisConfig) -> dict:
    batch = parser.parse_uploads(files)
    analyzer = WorkflowAnalyzer(config)
    analyses = []
    for dataset in batch.datasets:
        try:
            result = analyzer.analyze(dataset.data).model_dump()
            result["dataset_name"] = dataset.name
            result["source_path"] = dataset.source_path
            analyses.append(result)
        except ValueError as exc:
            batch.failures.append(type(batch.failures[0] if batch.failures else object)(name=dataset.source_path, error=str(exc)))
    payload = {
        "analyses": analyses,
        "failures": [{"name": failure.name, "error": failure.error} for failure in batch.failures],
    }
    if not analyses:
        detail = "\n".join([f"Failed to parse dataset: {item['name']} - {item['error']}" for item in payload["failures"]]) or "No supported datasets were found."
        raise HTTPException(status_code=400, detail=detail)
    return payload


@app.get("/", response_class=HTMLResponse)
async def home(request: Request) -> HTMLResponse:
    return templates.TemplateResponse(request=request, name="index.html", context={})


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/api/sample")
async def sample() -> dict:
    df = pd.read_csv(SAMPLE_DATA)
    analyzer = WorkflowAnalyzer(AnalysisConfig())
    result = analyzer.analyze(df).model_dump()
    result["dataset_name"] = SAMPLE_DATA.name
    return result


@app.post("/api/analyze")
async def analyze_workflow(
    file: UploadFile = File(...),
    case_id_col: str = Query(default="case_id"),
    timestamp_col: str = Query(default="timestamp"),
    activity_col: str = Query(default="activity"),
    actor_col: str = Query(default="actor"),
    duration_hours_col: str = Query(default="duration_hours"),
    status_col: str = Query(default="status"),
    variant_support_threshold: float = Query(default=0.15),
    sla_hours: float = Query(default=72.0),
    top_n_deviations: int = Query(default=10),
) -> dict:
    config = build_config(
        case_id_col=case_id_col,
        timestamp_col=timestamp_col,
        activity_col=activity_col,
        actor_col=actor_col,
        duration_hours_col=duration_hours_col,
        status_col=status_col,
        variant_support_threshold=variant_support_threshold,
        sla_hours=sla_hours,
        top_n_deviations=top_n_deviations,
    )
    payload = _analyze_batch([file], config)
    analyses = payload["analyses"]
    if len(analyses) != 1:
        raise HTTPException(
            status_code=400,
            detail="Uploaded source expands to multiple datasets. Use the multi-dataset endpoint or upload one dataset at a time.",
        )
    result = analyses[0]
    result["failures"] = payload["failures"]
    return result


@app.post("/api/analyze-multiple")
async def analyze_multiple_workflows(
    files: list[UploadFile] = File(...),
    case_id_col: str = Query(default="case_id"),
    timestamp_col: str = Query(default="timestamp"),
    activity_col: str = Query(default="activity"),
    actor_col: str = Query(default="actor"),
    duration_hours_col: str = Query(default="duration_hours"),
    status_col: str = Query(default="status"),
    variant_support_threshold: float = Query(default=0.15),
    sla_hours: float = Query(default=72.0),
    top_n_deviations: int = Query(default=10),
) -> dict:
    if not files:
        raise HTTPException(status_code=400, detail="Please upload at least one workflow file.")
    config = build_config(
        case_id_col=case_id_col,
        timestamp_col=timestamp_col,
        activity_col=activity_col,
        actor_col=actor_col,
        duration_hours_col=duration_hours_col,
        status_col=status_col,
        variant_support_threshold=variant_support_threshold,
        sla_hours=sla_hours,
        top_n_deviations=top_n_deviations,
    )
    return _analyze_batch(files, config)
